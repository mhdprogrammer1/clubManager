
module.exports = function (appSettings) {
    var express = require('express');
    var router = express.Router();

    var namespaces = appSettings.socket.namespaces;
    //var notification_producer=require('../util/notificationProducer');


    // _id: transition._id,
    // userId: transition._from,
    // _to: transition._to,
    // category: transition.category,
    // menu: transition.menu,
    // subMenu: transition.subMenu,
    // action: transition.action,
    // actionId: transition.actionid,
    // date: transition.date,
    // lastStatus: transition.lastStatus,
    // orginalQueueNumber: transition.playerOrginalQueueCount,
    // reservedQueueNumber: transition.playerReservedQueueCount,
    router.get('/', function (req, res) {
        appSettings.socket.io.emit("test", "test")
        // notification_producer.publishMessageToQueue(req,res);
        console.log("get result........................" + JSON.stringify(req.body));
    });
    router.post('/publish', function (req, res) {
        var io = appSettings.socket.io;
        var data = req.body;
        var sockets = req.body.sockets;
        if (sockets) {
            for (let index = 0; index < sockets.length; index++) {
                const socket = sockets[index];
                // if (io.sockets.connected[socket.id]) {
                io.to(socket.id).emit('tournament_addPlayer', data);
                // } else {
                //     appSettings.taskProducer.publishMessageToQueue({ action: 'delete_socket', socketId: socket.id, userId: data.userId })
                // }
            }
            appSettings.taskProducer.publishMessageToQueue(appSettings,{ action: 'delete_socket', sockets: sockets, userId: data.userId })
        }
        // notification_producer.publishMessageToQueue(req,res);
        console.log("get result........................" + JSON.stringify(req.body));
        res.send({ succesed: true });
    });
    return router;
};
