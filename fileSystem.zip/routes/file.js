

var express = require('express');
var multer = require('multer');
var router = express.Router();
var jwt = require('express-jwt');
var qs = require('querystring');


function baseAddresses(baseAdress) {
    // always initialize all instance properties
    this.base = baseAdress;
    this.user = this.base + "users\\";
    this.profile = this.user + "profile\\";
    this.post = this.user + "post\\";
    this.tornament = this.user + "tornament\\";


    this.admin = this.base + "_admin\\";
    this.category = this.admin + "category"
}
const baseAdress = new baseAddresses("c:\\clubFiles\\");


var fs = require('fs');

function createDirIfNotExsist(dir) {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
    }
}
for (const key in baseAdress) {
    if (baseAdress.hasOwnProperty(key)) {
        const element = baseAdress[key];
        createDirIfNotExsist(element)
    }
}
var getUserId = function (req) {
    var splitedUserId = req.user.uid.split('/');
    return splitedUserId[splitedUserId.length - 1];
}
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        var userId = getUserId(req);
        var dir = baseAdress[file.fieldname] + userId + "\\";
        req.fileDate = { dir: dir };
        createDirIfNotExsist(dir);
        cb(null, dir);
    },
    filename: function (req, file, cb) {
        var userId = getUserId(req);
        var fileName = Date.now() + "-" + file.originalname;
        req.fileDate.fileName = fileName;
        req.fileDate.mimetype = file.mimetype;
        cb(null, fileName)
    }
})
var upload = multer({ storage: storage });

router.get('/get/:id', function (req, res) {
    if (!req.user) return res.sendStatus(401);
    res.sendFile(req.params.id);
});

router.post('/profile', function (req, res) {
    if (!req.user) return res.sendStatus(401);
    upload.single("profile")(req, res, function (err) {
        if (err) {
            // An error occurred when uploading
            return
        }
        var es = qs.escape(req.fileDate.dir + req.fileDate.fileName);
        res.send({ fileId: es });

    });
});

router.post('/post', function (req, res) {
    if (!req.user) return res.sendStatus(401);
    upload.single("post")(req, res, function (err) {
        if (err) {
            // An error occurred when uploading
            return
        }
        var es = qs.escape(req.fileDate.dir + req.fileDate.fileName);
        res.send({ fileId: es });

    });
});

router.post('/tornament', function (req, res) {
    if (!req.user) return res.sendStatus(401);
    upload.single("tornament")(req, res, function (err) {
        console.log(process.pid);
        if (err) {
            // An error occurred when uploading
            return
        }
        var es = qs.escape(req.fileDate.dir + req.fileDate.fileName);
        res.send({ fileId: es });

    });

});

router.post('/category', function (req, res) {
    if (!req.user) return res.sendStatus(401);
    upload.single("category")(req, res, function (err) {
        if (err) {
            // An error occurred when uploading
            return
        }
        var es = qs.escape(req.fileDate.dir + req.fileDate.fileName);
        res.send({ fileId: es });
    });
});


module.exports = router;
