var appSettings = { socket: { io: {}, namespaces: {} }, settings: {} };
const express = require('express'),
  config = require("./config.json"),
  path = require('path'),
  favicon = require('serve-favicon'),
  logger = require('morgan'),
  cookieParser = require('cookie-parser'),
  bodyParser = require('body-parser'),
  jwt = require('express-jwt'),
  Database = require("arangojs").Database,
  http = require('http'),
  request = require('request'),
  index = require('./routes/index'),
  notifications = require('./routes/notification')(appSettings),
  initSockets = require('./util/socket/initSockets'),
  socketInit = require('./util/socket/initSockets'),
  taskProducer = require("./util/kafka/appTasksProducer"),
  files = require('./routes/file'),
  tournament_addPlayer = require('./util/kafka/tournament_addPlayer'),
  appTasksConsumer = require('./util/kafka/appTasksConsumer');

appSettings.taskProducer = taskProducer;
var app = express();
var port = normalizePort(process.env.PORT || '3001');
var server = app.listen(port);
server.on('error', onError);
server.on('listening', onListening);

var debug = require('debug')('filesystem:server');

// var users = require('./routes/users');
//#region database
const db = new Database({
  url: config.dbServers[0]
});
db.useBasicAuth("root", "root");
db.useDatabase("clubManager");

var foxxSettings = db.collection("club_foxxy_settings");
var getFoxxSettings = foxxSettings.firstExample({})
//#endregion

app.use(express.static(path.join(__dirname, 'node_modules')));

getFoxxSettings.then(
  settings => {
    appSettings.settings = settings;
    socketInit(server, appSettings);
    return appSettings;
  }).then(appSettings => {
    console.log(appSettings.settings.jwt_secret);
    app.use(jwt({
      secret: appSettings.settings.jwt_secret,
      credentialsRequired: false,
      getToken: function fromHeaderOrQuerystring(req, res, next) {
        if (req.headers["x-session-id"]) {
          return req.headers["x-session-id"];
        } else if (req.query && req.query.token) {
          return req.query.token;
        }
        return null;
      }
    }));
    app.use(logger('dev'));
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: false }));
    app.use(cookieParser());
    app.use(express.static(path.join(__dirname, 'public')));

    app.use('/files', files);
    app.use('/notifications', notifications);
    app.use('/', index);
    tournament_addPlayer(appSettings);
    appTasksConsumer(appSettings);
    // view engine setup
    app.set('views', path.join(__dirname, 'views'));
    app.set('view engine', 'jade');

    // uncomment after placing your favicon in /public
    //app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));


    // app.use('/users', users);


    // catch 404 and forward to error handler
    app.use(function (req, res, next) {
      var err = new Error('Not Found');
      err.status = 404;
      next(err);
    });
    app.use(function (err, req, res, next) {
      if (err.name === 'UnauthorizedError') {
        res.status(401).send({ successed: false, errorCode: 401, message: 'Not authenticated' });
      }
    });

    // error handler
    app.use(function (err, req, res, next) {
      // set locals, only providing error in development
      res.locals.message = err.message;
      res.locals.error = req.app.get('env') === 'development' ? err : {};

      // render the error page
      res.status(err.status || 500);
      res.render('error');
    });
  },
    err => {
      console.error('Failed to fetch document:', err)

    }
  );

/**
 * Normalize a port into a number, string, or false.
 */

function normalizePort(val) {
  var port = parseInt(val, 10);

  if (isNaN(port)) {
    // named pipe
    return val;
  }

  if (port >= 0) {
    // port number
    return port;
  }

  return false;
}

/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  var bind = typeof port === 'string'
    ? 'Pipe ' + port
    : 'Port ' + port;

  // handle specific listen errors with friendly messages
  switch (error.code) {
    case 'EACCES':
      console.error(bind + ' requires elevated privileges');
      process.exit(1);
      break;
    case 'EADDRINUSE':
      console.error(bind + ' is already in use');
      process.exit(1);
      break;
    default:
      throw error;
  }
}

/**
 * Event listener for HTTP server "listening" event.
 */

function onListening(req, res) {
  var addr = server.address();

  var bind = typeof addr === 'string'
    ? 'pipe ' + addr
    : 'port ' + addr.port;
  debug('Listening on ' + bind);
  require('dns').lookup(require('os').hostname(), function (err, add, fam) {
    var serverAddress = `http://${add}:${addr.port}`;
    console.log('addr: ' + serverAddress);
  })
}